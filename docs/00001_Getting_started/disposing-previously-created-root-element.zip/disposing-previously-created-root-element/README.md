# Disposing previously created Root element

A Pen created on CodePen.io. Original URL: [https://codepen.io/team/amcharts/pen/GROEEXP](https://codepen.io/team/amcharts/pen/GROEEXP).

