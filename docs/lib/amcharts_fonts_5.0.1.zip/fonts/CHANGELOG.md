# amCharts 5 PDF Font Pack Changelog

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/).

Please note, that this project, while following numbering syntax, it DOES NOT
adhere to [Semantic Versioning](http://semver.org/spec/v2.0.0.html) rules.

## [5.0.1] - 2021-08-25
- Version bump.


## [5.0.0] - 2021-08-20

### Added
- Initial release.
